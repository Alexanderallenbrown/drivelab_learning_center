var classModbusSerial =
[
    [ "ModbusSerial", "classModbusSerial.html#add48c6a2b436e600865e0cf63ed0aafc", null ],
    [ "config", "classModbusSerial.html#aefa9a7f9a910a311bfcd5110a6a8ab71", null ],
    [ "config", "classModbusSerial.html#abbe69850e5deb5c35c6a2075a372350c", null ],
    [ "config", "classModbusSerial.html#a82286ed2d9415c624d9b557fe871d8a0", null ],
    [ "getSlaveId", "classModbusSerial.html#adefaff8d3e8f4cfc1d90c9b52d880262", null ],
    [ "receive", "classModbusSerial.html#a3fb991a7b8d0d9766889e2cad7fca115", null ],
    [ "send", "classModbusSerial.html#ae7b2f3574d102b26a1de084cb345b6cc", null ],
    [ "sendPDU", "classModbusSerial.html#a69850777f84662664dd17e137250e3b0", null ],
    [ "setSlaveId", "classModbusSerial.html#a2b727d4d516177e698db6e49729624d8", null ],
    [ "task", "classModbusSerial.html#ad47e2b6a70d42a106a1a55a515e2f33a", null ]
];