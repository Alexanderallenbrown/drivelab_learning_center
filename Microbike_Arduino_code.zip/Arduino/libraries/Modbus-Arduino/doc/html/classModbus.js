var classModbus =
[
    [ "Modbus", "classModbus.html#a101809cdd4734537bab58dc315a840b4", null ],
    [ "addCoil", "classModbus.html#af10a81e46f971daa4ce429d39776378b", null ],
    [ "addHreg", "classModbus.html#a73797fbd9af758aedc198ccd8f4585fb", null ],
    [ "addIreg", "classModbus.html#ab052ca5452b76bdb85235e898623cedc", null ],
    [ "addIsts", "classModbus.html#abead971752bc7b2a54cb508ad8a8a2c4", null ],
    [ "Coil", "classModbus.html#a6b5ed2b967d4c43b578d21f562abc007", null ],
    [ "Coil", "classModbus.html#a208bb15086e008f05f2fa72398551d04", null ],
    [ "Hreg", "classModbus.html#af13802f39b91279bd55538749bb76409", null ],
    [ "Hreg", "classModbus.html#aa6b32867beace3ce557ea61183497607", null ],
    [ "Ireg", "classModbus.html#ac9be098d4bff9081105b6202922b1134", null ],
    [ "Ireg", "classModbus.html#abef420732eca033c08c131df73623521", null ],
    [ "Ists", "classModbus.html#a493b0fc75ea3ba076f7c9a25e491bcbe", null ],
    [ "Ists", "classModbus.html#a833a76980e46be4995d2ca4ce5d2e51b", null ]
];