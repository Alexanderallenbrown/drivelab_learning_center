var hierarchy =
[
    [ "Modbus", "classModbus.html", [
      [ "ModbusIP", "classModbusIP.html", null ],
      [ "ModbusIP", "classModbusIP.html", null ],
      [ "ModbusIP", "classModbusIP.html", null ],
      [ "ModbusSerial", "classModbusSerial.html", null ]
    ] ],
    [ "ModbusIP_ENC28J60", "classModbusIP__ENC28J60.html", null ],
    [ "ModbusIP_ESP8266AT", "classModbusIP__ESP8266AT.html", null ]
];