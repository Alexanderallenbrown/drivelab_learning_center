#pragma once

void fast_ble_on_reset(int reason);
void fast_ble_on_sync(void);
